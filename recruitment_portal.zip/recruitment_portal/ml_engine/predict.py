from pathlib import Path
import joblib, numpy as np
MODEL=Path(__file__).with_name('shortlist_model.joblib')
def predict_candidate(data):
 x=np.array([[float(data.get('experience_months',0)),float(data.get('notice_period_days',0)),float(data.get('expected_salary',0)),float(data.get('skill_score',0))]])
 if MODEL.exists():
  m=joblib.load(MODEL); p=float(m.predict_proba(x)[0,1]); return {'prediction':int(p>=.5),'confidence':p}
 score=min(1.0,.15+x[0,0]/60*.35+x[0,3]/100*.5); return {'prediction':int(score>=.5),'confidence':float(score),'note':'fallback rule score; train model first'}
