import pandas as pd,numpy as np
from pathlib import Path
from tensorflow import keras
D=Path(__file__).parents[1]/'data/sample_candidates.csv'; df=pd.read_csv(D)
X=df[['experience_months','notice_period_days','expected_salary','skill_score']].fillna(0).astype('float32').values; X=(X-X.mean(0))/(X.std(0)+1e-6); y=(df.historical_selection_status.str.lower()=='selected').astype('float32').values
m=keras.Sequential([keras.layers.Input((4,)),keras.layers.Dense(8,activation='relu'),keras.layers.Dense(1,activation='sigmoid')]); m.compile(optimizer='adam',loss='binary_crossentropy',metrics=['accuracy']); m.fit(X,y,epochs=10,verbose=1); m.save(Path(__file__).with_name('shortlist_ann.keras'))
