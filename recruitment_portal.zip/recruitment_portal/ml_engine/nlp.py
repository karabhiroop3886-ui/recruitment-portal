import nltk
from nltk import word_tokenize,pos_tag
from sklearn.feature_extraction.text import TfidfVectorizer
def analyze_resume(text,skills):
 tokens=word_tokenize(text.lower()); tagged=pos_tag(tokens); required={s.strip().lower() for s in skills.split(',') if s.strip()}; matched={s for s in required if s in text.lower()}; score=100*len(matched)/max(1,len(required)); vec=TfidfVectorizer(max_features=50).fit_transform([text]).toarray().tolist(); return {'tokens':tokens[:50],'pos':tagged[:50],'skill_match_score':score,'vector':vec}
