import pandas as pd,numpy as np,joblib
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
DATA=Path(__file__).parents[1]/'data/sample_candidates.csv'; df=pd.read_csv(DATA).drop_duplicates(); df=df.drop(columns=['candidate_name','email','phone','resume_text','portfolio_url','college','applied_role','skills'],errors='ignore')
df['target']=(df['historical_selection_status'].str.lower()=='selected').astype(int); df=df.drop(columns=['historical_selection_status'])
X=df[['experience_months','notice_period_days','expected_salary','skill_score']]; y=df.target
lo,hi=X.expected_salary.quantile([.01,.99]); X=X[(X.expected_salary>=lo)&(X.expected_salary<=hi)]; y=y.loc[X.index]
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.25,random_state=42,stratify=y)
for model in [LogisticRegression(max_iter=1000),RandomForestClassifier(n_estimators=100,random_state=42)]:
 p=Pipeline([('impute',SimpleImputer(strategy='median')),('model',model)]); p.fit(Xtr,ytr); print(type(model).__name__,accuracy_score(yte,p.predict(Xte)))
best=Pipeline([('impute',SimpleImputer(strategy='median')),('model',RandomForestClassifier(n_estimators=100,random_state=42))]); best.fit(X,y); joblib.dump(best,Path(__file__).with_name('shortlist_model.joblib'))
