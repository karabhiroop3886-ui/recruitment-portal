from django.urls import path
from . import views
urlpatterns=[path('',views.dashboard,name='dashboard'),path('upload/',views.upload_candidates,name='upload'),path('batch/<int:pk>/',views.batch_status,name='batch_status'),path(
    'candidate/add/',
    views.candidate_create,
    name='candidate_create'
),
path(
    'interviews/schedule/',
    views.schedule_interview,
    name='schedule_interview'
),
path(
    "batch/select/",
    views.select_batch,
    name="select_batch"
),
path('candidate/<int:pk>/',views.candidate_detail,name='candidate_detail'),path('candidate/<int:pk>/screening/',views.screening_edit,name='screening_edit'),path('candidate/<int:pk>/delete/',views.candidate_delete,name='candidate_delete'),path('ajax/duplicate-email/',views.duplicate_email,name='duplicate_email'),path('ajax/slots/<int:role_id>/',views.slots_for_role,name='slots'),path('json/candidates/',views.candidates_json),path('json/candidates/<int:pk>/',views.candidates_json)]
