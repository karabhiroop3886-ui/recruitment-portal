from celery import shared_task
from django.core.cache import cache
from .models import ApplicationBatch,JobRole,Candidate,ScreeningResult
from .ingestion import ingest_file
@shared_task(bind=True)
def process_batch(self,batch_id):
 b=ApplicationBatch.objects.get(pk=batch_id); b.status='RUNNING'; b.save(update_fields=['status'])
 try:
  rows,rejected=ingest_file(b.file.path)
  total=max(len(rows),1)
  for i,r in enumerate(rows,1):
   role,_=JobRole.objects.get_or_create(name=r['applied_role'])
   c,_=Candidate.objects.update_or_create(email=r['email'],defaults={'name':r['candidate_name'],'phone':r['phone'],'college':r['college'],'role':role,'skills':r['skills'],'experience_months':int(float(r['experience_months'])),'notice_period_days':int(float(r['notice_period_days'])),'expected_salary':float(r['expected_salary']),'resume_text':r.get('resume_text',''),'portfolio_url':r.get('portfolio_url',''),'historical_selection_status':r.get('historical_selection_status',''),'batch':b})
   ScreeningResult.objects.get_or_create(candidate=c); b.progress=int(i*100/total); b.save(update_fields=['progress'])
  b.status='DONE'; b.progress=100; b.save(update_fields=['status','progress']); cache.delete('top_shortlisted')
 except Exception as e: b.status='FAILED'; b.error=str(e); b.save(update_fields=['status','error']); raise
