from django.db import models
from django.contrib.auth.models import User
class JobRole(models.Model):
 name=models.CharField(max_length=100,unique=True); required_skills=models.CharField(max_length=500,blank=True); min_experience_months=models.PositiveIntegerField(default=0)
 def __str__(self): return self.name
class ApplicationBatch(models.Model):
 file=models.FileField(upload_to='batches/'); uploaded_by=models.ForeignKey(User,on_delete=models.SET_NULL,null=True); created_at=models.DateTimeField(auto_now_add=True); status=models.CharField(max_length=20,default='PENDING'); progress=models.PositiveIntegerField(default=0); error=models.TextField(blank=True)
class Candidate(models.Model):
 name=models.CharField(max_length=150); email=models.EmailField(unique=True); phone=models.CharField(max_length=20); college=models.CharField(max_length=150); role=models.ForeignKey(JobRole,on_delete=models.PROTECT); skills=models.TextField(); experience_months=models.PositiveIntegerField(default=0); notice_period_days=models.PositiveIntegerField(default=0); expected_salary=models.DecimalField(max_digits=12,decimal_places=2,default=0); resume_text=models.TextField(blank=True); portfolio_url=models.URLField(blank=True); resume_file=models.FileField(upload_to='resumes/',blank=True,null=True); historical_selection_status=models.CharField(max_length=30,blank=True); batch=models.ForeignKey(ApplicationBatch,on_delete=models.SET_NULL,null=True,blank=True); created_at=models.DateTimeField(auto_now_add=True)
 def __str__(self): return f'{self.name} - {self.email}'
class ScreeningResult(models.Model):
 STATUS=[('PENDING','Pending'),('SELECTED','Selected'),('REJECTED','Rejected'),('WAITLISTED','Waitlisted')]
 candidate=models.OneToOneField(Candidate,on_delete=models.CASCADE); rule_score=models.FloatField(default=0); ml_score=models.FloatField(default=0); nlp_score=models.FloatField(default=0); status=models.CharField(max_length=20,choices=STATUS,default='PENDING'); updated_at=models.DateTimeField(auto_now=True)
class InterviewSlot(models.Model):
    role = models.ForeignKey(JobRole, on_delete=models.CASCADE)

    start_at = models.DateTimeField()

    interviewer = models.ForeignKey(
        User,
        on_delete=models.CASCADE
    )

    candidate = models.ForeignKey(
        Candidate,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    is_booked = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.role.name} - {self.start_at}"
class InterviewFeedback(models.Model):
 candidate=models.ForeignKey(Candidate,on_delete=models.CASCADE); interviewer=models.ForeignKey(User,on_delete=models.CASCADE); rating=models.PositiveSmallIntegerField(); comments=models.TextField(blank=True); created_at=models.DateTimeField(auto_now_add=True)
