from django import forms
from .models import ApplicationBatch, ScreeningResult, Candidate
class UploadForm(forms.ModelForm):
 class Meta: model=ApplicationBatch; fields=['file']
 def clean_file(self):
  f=self.cleaned_data['file']
  if not f.name.lower().endswith(('.csv','.xlsx','.xls')): raise forms.ValidationError('Only CSV/Excel files are allowed.')
  if f.size==0: raise forms.ValidationError('Empty file.')
  return f
class ScreeningForm(forms.ModelForm):
 class Meta: model=ScreeningResult; fields=['status']

class CandidateForm(forms.ModelForm):
    class Meta:
        model = Candidate
        fields = [
            'name',
            'email',
            'phone',
            'college',
            'role',
            'skills',
            'experience_months',
            'notice_period_days',
            'expected_salary',
            'resume_text',
            'portfolio_url',
            'resume_file',
            'historical_selection_status',
        ]