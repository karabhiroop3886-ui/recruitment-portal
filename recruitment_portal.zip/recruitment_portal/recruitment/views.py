from django.contrib.auth.decorators import login_required
from django.shortcuts import render,redirect,get_object_or_404
from django.http import JsonResponse
from django.db.models import Count,Avg,Min,Max,Sum
from .models import *
from .forms import UploadForm,ScreeningForm,CandidateForm
from .tasks import process_batch
from .models import (
    Candidate,
    JobRole,
    ApplicationBatch,
    ScreeningResult,
    InterviewSlot,
    InterviewFeedback,
)
@login_required
def dashboard(request):

    # -----------------------------------
    # 1. ROLE FILTER USING COOKIE
    # -----------------------------------

    selected_role = request.GET.get("role")

    # If role is not coming from URL,
    # try to get the previously selected role from cookie
    if not selected_role:
        selected_role = request.COOKIES.get("selected_role", "")

    candidates = Candidate.objects.all()

    # Filter candidates by selected role
    if selected_role:
        candidates = candidates.filter(role_id=selected_role)


    # -----------------------------------
    # 2. CURRENT SCREENING BATCH
    #    USING DJANGO SESSION
    # -----------------------------------

    current_batch_id = request.session.get("current_batch_id")

    current_batch = None

    if current_batch_id:
        current_batch = ApplicationBatch.objects.filter(
            id=current_batch_id
        ).first()


    # -----------------------------------
    # 3. GET ALL JOB ROLES
    # -----------------------------------

    roles = JobRole.objects.all()


    # -----------------------------------
    # 4. GET ALL APPLICATION BATCHES
    # -----------------------------------

    batches = ApplicationBatch.objects.all().order_by("-id")


    # -----------------------------------
    # 5. DASHBOARD STATISTICS
    # -----------------------------------

    total_candidates = Candidate.objects.count()

    total_batches = ApplicationBatch.objects.count()

    total_interviews = InterviewSlot.objects.count()

    booked_interviews = InterviewSlot.objects.filter(
        is_booked=True
    ).count()


    # -----------------------------------
    # 6. RENDER DASHBOARD
    # -----------------------------------

    response = render(
        request,
        "recruitment/dashboard.html",
        {
            "candidates": candidates,

            "roles": roles,

            "selected_role": selected_role,

            "batches": batches,

            "current_batch": current_batch,

            "total_candidates": total_candidates,

            "total_batches": total_batches,

            "total_interviews": total_interviews,

            "booked_interviews": booked_interviews,
        }
    )


    # -----------------------------------
    # 7. SAVE ROLE FILTER IN COOKIE
    # -----------------------------------

    if request.GET.get("role") is not None:

        response.set_cookie(
            "selected_role",
            selected_role,
            max_age=60 * 60 * 24 * 30
        )


    return response

@login_required
def select_batch(request):

    if request.method == "POST":

        batch_id = request.POST.get("batch")

        if batch_id:
            request.session["current_batch_id"] = batch_id

    return redirect("dashboard")
@login_required
def upload_candidates(request):
 form=UploadForm(request.POST or None,request.FILES or None)
 if request.method=='POST' and form.is_valid():
  b=form.save(commit=False); b.uploaded_by=request.user; b.save(); request.session['current_batch']=b.id; process_batch.delay(b.id); return redirect('batch_status',b.id)
 return render(request,'recruitment/upload.html',{'form':form})
@login_required
def batch_status(request,pk): return render(request,'recruitment/batch_status.html',{'batch':get_object_or_404(ApplicationBatch,pk=pk)})
@login_required
def candidate_detail(request,pk): return render(request,'recruitment/detail.html',{'candidate':get_object_or_404(Candidate,pk=pk)})
@login_required
def screening_edit(request,pk):
 s=get_object_or_404(ScreeningResult,candidate_id=pk); form=ScreeningForm(request.POST or None,instance=s)
 if request.method=='POST' and form.is_valid(): form.save(); return redirect('candidate_detail',pk)
 return render(request,'recruitment/form.html',{'form':form})
@login_required
def candidate_delete(request,pk):
 c=get_object_or_404(Candidate,pk=pk)
 if request.method=='POST': c.delete(); return redirect('dashboard')
 return render(request,'recruitment/delete.html',{'candidate':c})
def duplicate_email(request): return JsonResponse({'exists':Candidate.objects.filter(email__iexact=request.GET.get('email','')).exists()})
def slots_for_role(request,role_id): return JsonResponse({'slots':list(InterviewSlot.objects.filter(role_id=role_id,is_booked=False).values('id','start_at'))})
def candidates_json(request,pk=None):
 q=Candidate.objects.all()
 if pk: q=q.filter(pk=pk)
 return JsonResponse(list(q.values('id','name','email','role__name','skills')),safe=False)

@login_required
def candidate_create(request):
    form = CandidateForm(request.POST or None, request.FILES or None)

    if request.method == 'POST' and form.is_valid():
        candidate = form.save()

        ScreeningResult.objects.get_or_create(
            candidate=candidate
        )

        return redirect('candidate_detail', candidate.pk)

    return render(
        request,
        'recruitment/candidate_form.html',
        {'form': form}
    )

@login_required
def schedule_interview(request):

    candidates = Candidate.objects.all()
    roles = JobRole.objects.all()

    if request.method == "POST":

        candidate_id = request.POST.get("candidate")
        role_id = request.POST.get("role")
        slot_id = request.POST.get("slot")

        candidate = get_object_or_404(
            Candidate,
            id=candidate_id
        )

        slot = get_object_or_404(
            InterviewSlot,
            id=slot_id,
            role_id=role_id,
            is_booked=False
        )

        slot.candidate = candidate
        slot.is_booked = True
        slot.save()

        return render(
            request,
            "recruitment/interview_success.html",
            {
                "candidate": candidate,
                "slot": slot
            }
        )

    return render(
        request,
        "recruitment/schedule_interview.html",
        {
            "candidates": candidates,
            "roles": roles
        }
    )

@login_required
def select_batch(request):
    if request.method == "POST":
        batch_id = request.POST.get("batch")

        if batch_id:
            request.session["current_batch_id"] = batch_id

        return redirect("dashboard")

    return redirect("dashboard")