import re,csv,copy
from pathlib import Path
import pandas as pd
REQUIRED=['candidate_name','email','phone','college','applied_role','skills','experience_months','notice_period_days','expected_salary','resume_text','portfolio_url','historical_selection_status']
class InvalidCandidate(Exception): pass
def audited(fn):
 def wrap(*args,**kwargs): return fn(*args,**kwargs)
 return wrap
def recursive_clean(v):
 if isinstance(v,str): return ' '.join(v.strip().split())
 if isinstance(v,list): return [recursive_clean(x) for x in v]
 return v
@audited
def validate_row(row):
 row=copy.deepcopy(row); row={k:recursive_clean(v) for k,v in row.items()}
 if not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',str(row['email']).lower()): raise InvalidCandidate('invalid email')
 phone=re.sub(r'\D','',str(row['phone']))
 if len(phone)<10 or len(phone)>15: raise InvalidCandidate('invalid phone')
 for k in ('experience_months','notice_period_days','expected_salary'):
  try: float(row[k])
  except: raise InvalidCandidate(f'invalid {k}')
 row['email']=str(row['email']).lower(); row['phone']=phone; return row
def ingest_file(path,out_dir='data'):
 p=Path(path); df=pd.read_csv(p) if p.suffix.lower()=='.csv' else pd.read_excel(p)
 if df.empty: raise InvalidCandidate('empty uploaded file')
 missing=set(REQUIRED)-set(df.columns)
 if missing: raise InvalidCandidate('missing columns: '+','.join(sorted(missing)))
 df=df.drop_duplicates(); accepted=[]; rejected=[]
 it=iter(df.to_dict('records'))
 while True:
  try: row=next(it)
  except StopIteration: break
  try: accepted.append(validate_row(row))
  except InvalidCandidate as e: row['reason']=str(e); rejected.append(row); continue
 out=Path(out_dir); out.mkdir(exist_ok=True); pd.DataFrame(accepted).to_csv(out/'accepted_rows.csv',index=False); pd.DataFrame(rejected).to_csv(out/'rejected_rows.csv',index=False)
 return accepted,rejected
