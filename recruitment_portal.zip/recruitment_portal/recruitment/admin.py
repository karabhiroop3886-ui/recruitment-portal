from django.contrib import admin
from .models import *
@admin.register(Candidate)
class CandidateAdmin(admin.ModelAdmin):
 list_display=('name','email','role','experience_months','expected_salary'); list_filter=('role','college'); search_fields=('name','email','skills'); fieldsets=((None,{'fields':('name','email','phone','college','role')}),('Profile',{'fields':('skills','experience_months','notice_period_days','expected_salary','resume_text','portfolio_url','resume_file')}))
admin.site.register([JobRole,ApplicationBatch,ScreeningResult,InterviewSlot,InterviewFeedback])
