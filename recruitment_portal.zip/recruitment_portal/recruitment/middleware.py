import time
from django.shortcuts import redirect
from django.urls import reverse


class RequestLoggingMiddleware:
    """
    Custom middleware for:
    1. Logging request path
    2. Logging request method
    3. Logging processing time
    4. Logging user role
    5. Blocking unauthenticated users from protected internal pages
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):

        start_time = time.time()

        # ----------------------------------------
        # PATHS THAT SHOULD REQUIRE LOGIN
        # ----------------------------------------

        protected_paths = [
            "/",
            "/upload/",
            "/candidate/",
            "/interviews/",
            "/batch/",
        ]

        # Paths that must stay accessible
        excluded_paths = [
            "/admin/login/",
            "/admin/logout/",
            "/api/",
            "/static/",
            "/media/",
        ]

        # ----------------------------------------
        # BLOCK UNAUTHENTICATED USERS
        # ----------------------------------------

        is_excluded = any(
            request.path.startswith(path)
            for path in excluded_paths
        )

        is_protected = any(
            request.path.startswith(path)
            for path in protected_paths
        )

        if (
            is_protected
            and not is_excluded
            and not request.user.is_authenticated
        ):
            return redirect("/admin/login/")

        # ----------------------------------------
        # PROCESS REQUEST
        # ----------------------------------------

        response = self.get_response(request)

        # ----------------------------------------
        # CALCULATE PROCESSING TIME
        # ----------------------------------------

        end_time = time.time()

        processing_time = round(
            end_time - start_time,
            4
        )

        # ----------------------------------------
        # FIND USER ROLE
        # ----------------------------------------

        role = "Anonymous"

        if request.user.is_authenticated:

            if request.user.is_superuser:
                role = "Admin"

            elif request.user.groups.filter(
                name__iexact="HR"
            ).exists():
                role = "HR"

            elif request.user.groups.filter(
                name__iexact="Interviewer"
            ).exists():
                role = "Interviewer"

            else:
                role = "Authenticated User"

        # ----------------------------------------
        # PRINT REQUEST LOG
        # ----------------------------------------

        print(
            f"[REQUEST LOG] "
            f"Path: {request.path} | "
            f"Method: {request.method} | "
            f"Time: {processing_time}s | "
            f"Role: {role}"
        )

        return response