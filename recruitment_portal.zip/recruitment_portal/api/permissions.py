from rest_framework.permissions import BasePermission


class IsAdminRole(BasePermission):
    """
    Only Django superusers are allowed.
    """

    message = "Only Admin users can perform this action."

    def has_permission(self, request, view):
        return (
            request.user
            and request.user.is_authenticated
            and request.user.is_superuser
        )


class IsHRRole(BasePermission):
    """
    HR users and Admin users are allowed.
    """

    message = "Only HR or Admin users can perform this action."

    def has_permission(self, request, view):

        if not request.user or not request.user.is_authenticated:
            return False

        if request.user.is_superuser:
            return True

        return request.user.groups.filter(
            name__iexact="HR"
        ).exists()


class IsInterviewerRole(BasePermission):
    """
    Interviewers and Admin users are allowed.
    """

    message = "Only Interviewer or Admin users can perform this action."

    def has_permission(self, request, view):

        if not request.user or not request.user.is_authenticated:
            return False

        if request.user.is_superuser:
            return True

        return request.user.groups.filter(
            name__iexact="Interviewer"
        ).exists()