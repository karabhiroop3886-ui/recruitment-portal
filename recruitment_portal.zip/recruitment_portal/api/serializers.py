from rest_framework import serializers

from recruitment.models import (
    Candidate,
    ScreeningResult,
    InterviewFeedback,
)


# =========================================================
# CANDIDATE SERIALIZER
# =========================================================

class CandidateSerializer(serializers.ModelSerializer):

    class Meta:
        model = Candidate

        fields = "__all__"


# =========================================================
# SCREENING RESULT SERIALIZER
# =========================================================

class ScreeningSerializer(serializers.ModelSerializer):

    candidate_name = serializers.CharField(
        source="candidate.name",
        read_only=True
    )

    class Meta:
        model = ScreeningResult

        fields = "__all__"


# =========================================================
# INTERVIEW FEEDBACK SERIALIZER
# =========================================================

class InterviewFeedbackSerializer(serializers.ModelSerializer):

    interviewer_name = serializers.CharField(
        source="interviewer.username",
        read_only=True
    )

    candidate_name = serializers.CharField(
        source="candidate.name",
        read_only=True
    )

    class Meta:
        model = InterviewFeedback

        fields = "__all__"

        # interviewer comes automatically
        # from request.user in views.py
        read_only_fields = [
            "interviewer",
            "created_at",
        ]


# =========================================================
# HYPERLINKED CANDIDATE SERIALIZER
# =========================================================

class CandidateLinkSerializer(
    serializers.HyperlinkedModelSerializer
):

    class Meta:
        model = Candidate

        fields = [
            "url",
            "id",
            "name",
            "email",
            "phone",
            "college",
            "role",
            "skills",
            "experience_months",
        ]

        extra_kwargs = {
            "url": {
                "view_name": "candidate-detail"
            }
        }