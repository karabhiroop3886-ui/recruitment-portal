from django.contrib.auth.models import User
from django.core.cache import cache
from django.shortcuts import get_object_or_404

from rest_framework import status, viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from rest_framework_simplejwt.tokens import RefreshToken

import random

from recruitment.models import (
    Candidate,
    ApplicationBatch,
    ScreeningResult,
    InterviewFeedback,
)

from .serializers import (
    CandidateSerializer,
    ScreeningSerializer,
    InterviewFeedbackSerializer,
)

from .permissions import (
    IsHRRole,
    IsInterviewerRole,
    IsAdminRole,
)


# =========================================================
# USER REGISTRATION
# =========================================================

@api_view(["POST"])
@permission_classes([AllowAny])
def register_user(request):
    """
    Register a new user.

    The user is created as inactive until OTP verification
    is successfully completed.
    """

    username = request.data.get("username")
    email = request.data.get("email")
    password = request.data.get("password")

    if not username or not email or not password:
        return Response(
            {
                "error": "username, email and password are required"
            },
            status=status.HTTP_400_BAD_REQUEST,
        )

    if User.objects.filter(username=username).exists():
        return Response(
            {
                "error": "Username already exists"
            },
            status=status.HTTP_400_BAD_REQUEST,
        )

    if User.objects.filter(email=email).exists():
        return Response(
            {
                "error": "Email already exists"
            },
            status=status.HTTP_400_BAD_REQUEST,
        )

    user = User.objects.create_user(
        username=username,
        email=email,
        password=password,
    )

    # User cannot login until OTP is verified
    user.is_active = False
    user.save()

    # Generate 6 digit OTP
    otp = str(random.randint(100000, 999999))

    # Store OTP in Redis cache for 5 minutes
    cache.set(
        f"otp_{username}",
        otp,
        timeout=300,
    )

    return Response(
        {
            "message": "User registered successfully. Verify OTP.",
            "development_otp": otp,
        },
        status=status.HTTP_201_CREATED,
    )


# =========================================================
# OTP VERIFICATION
# =========================================================

@api_view(["POST"])
@permission_classes([AllowAny])
def verify_otp(request):
    """
    Verify OTP and activate the user's account.
    """

    username = request.data.get("username")
    otp = request.data.get("otp")

    if not username or not otp:
        return Response(
            {
                "error": "username and otp are required"
            },
            status=status.HTTP_400_BAD_REQUEST,
        )

    stored_otp = cache.get(
        f"otp_{username}"
    )

    if stored_otp is None:
        return Response(
            {
                "error": "OTP expired or not found"
            },
            status=status.HTTP_400_BAD_REQUEST,
        )

    if str(stored_otp) != str(otp):
        return Response(
            {
                "error": "Invalid OTP"
            },
            status=status.HTTP_400_BAD_REQUEST,
        )

    try:
        user = User.objects.get(
            username=username
        )

    except User.DoesNotExist:
        return Response(
            {
                "error": "User not found"
            },
            status=status.HTTP_404_NOT_FOUND,
        )

    user.is_active = True
    user.save()

    # Delete OTP after successful verification
    cache.delete(
        f"otp_{username}"
    )

    return Response(
        {
            "message": "OTP verified successfully. Account activated."
        },
        status=status.HTTP_200_OK,
    )


# =========================================================
# LOGOUT
# =========================================================

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def logout_user(request):
    """
    Logout user by blacklisting refresh token.
    """

    refresh_token = request.data.get(
        "refresh"
    )

    if not refresh_token:
        return Response(
            {
                "error": "Refresh token is required"
            },
            status=status.HTTP_400_BAD_REQUEST,
        )

    try:

        token = RefreshToken(
            refresh_token
        )

        token.blacklist()

        return Response(
            {
                "message": "Logout successful"
            },
            status=status.HTTP_200_OK,
        )

    except Exception:
        return Response(
            {
                "error": "Invalid refresh token"
            },
            status=status.HTTP_400_BAD_REQUEST,
        )


# =========================================================
# CANDIDATE CRUD API
# HR + ADMIN ONLY
# =========================================================

class CandidateViewSet(
    viewsets.ModelViewSet
):

    queryset = Candidate.objects.all().order_by(
        "-id"
    )

    serializer_class = CandidateSerializer

    permission_classes = [
        IsHRRole
    ]


# =========================================================
# APPLICATION BATCH STATUS
# HR + ADMIN
# =========================================================

@api_view(["GET"])
@permission_classes([IsHRRole])
def batch_status(
    request,
    pk,
):

    batch = get_object_or_404(
        ApplicationBatch,
        pk=pk,
    )

    return Response(
        {
            "id": batch.id,
            "status": batch.status,
            "progress": batch.progress,
            "error": batch.error,
            "created_at": batch.created_at,
        }
    )


# =========================================================
# SCREENING RESULTS
# HR + ADMIN
# =========================================================

@api_view(["GET"])
@permission_classes([IsHRRole])
def screening_results(request):

    results = ScreeningResult.objects.all().order_by(
        "-id"
    )

    serializer = ScreeningSerializer(
    results,
    many=True,
)

    return Response(
        serializer.data
    )


# =========================================================
# INTERVIEW FEEDBACK
# INTERVIEWER + ADMIN
# =========================================================

@api_view(["POST"])
@permission_classes([IsInterviewerRole])
def submit_feedback(request):
    """
    Interviewers can submit interview feedback.
    Admin users are also allowed.
    """

    serializer = InterviewFeedbackSerializer(
        data=request.data
    )

    if serializer.is_valid():

        serializer.save(
            interviewer=request.user
        )

        return Response(
            serializer.data,
            status=status.HTTP_201_CREATED,
        )

    return Response(
        serializer.errors,
        status=status.HTTP_400_BAD_REQUEST,
    )


# =========================================================
# LIST INTERVIEW FEEDBACK
# INTERVIEWER + ADMIN
# =========================================================

@api_view(["GET"])
@permission_classes([IsInterviewerRole])
def feedback_list(request):

    feedback = InterviewFeedback.objects.all().order_by(
        "-created_at"
    )

    serializer = InterviewFeedbackSerializer(
        feedback,
        many=True,
    )

    return Response(
        serializer.data
    )


# =========================================================
# ADMIN TEST ENDPOINT
# ADMIN ONLY
# =========================================================

@api_view(["GET"])
@permission_classes([IsAdminRole])
def admin_only(request):

    return Response(
        {
            "message": "You have Admin access.",
            "username": request.user.username,
        }
    )


# =========================================================
# HR TEST ENDPOINT
# HR + ADMIN
# =========================================================

@api_view(["GET"])
@permission_classes([IsHRRole])
def hr_only(request):

    return Response(
        {
            "message": "You have HR access.",
            "username": request.user.username,
        }
    )


# =========================================================
# INTERVIEWER TEST ENDPOINT
# INTERVIEWER + ADMIN
# =========================================================

@api_view(["GET"])
@permission_classes([IsInterviewerRole])
def interviewer_only(request):

    return Response(
        {
            "message": "You have Interviewer access.",
            "username": request.user.username,
        }
    )