from django.urls import path, include

from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

from .views import (
    CandidateViewSet,
    register_user,
    verify_otp,
    logout_user,
    batch_status,
    screening_results,
    submit_feedback,
    feedback_list,
    admin_only,
    hr_only,
    interviewer_only,
)


# =========================================================
# ROUTER
# =========================================================

router = DefaultRouter()

router.register(
    "candidates",
    CandidateViewSet,
    basename="candidate",
)


# =========================================================
# URL PATTERNS
# =========================================================

urlpatterns = [

    # Candidate CRUD API
    path(
        "",
        include(router.urls),
    ),

    # JWT Login
    path(
        "login/",
        TokenObtainPairView.as_view(),
        name="api_login",
    ),

    # Refresh JWT token
    path(
        "token/refresh/",
        TokenRefreshView.as_view(),
        name="api_token_refresh",
    ),

    # Registration
    path(
        "register/",
        register_user,
        name="register_user",
    ),

    # OTP verification
    path(
        "verify-otp/",
        verify_otp,
        name="verify_otp",
    ),

    # Logout
    path(
        "logout/",
        logout_user,
        name="logout_user",
    ),

    # Batch status
    path(
        "batches/<int:pk>/status/",
        batch_status,
        name="batch_status_api",
    ),

    # Screening results
    path(
        "screening/",
        screening_results,
        name="screening_results_api",
    ),

    # Submit interview feedback
    path(
        "feedback/submit/",
        submit_feedback,
        name="submit_feedback_api",
    ),

    # List feedback
    path(
        "feedback/",
        feedback_list,
        name="feedback_list_api",
    ),

    # Role testing
    path(
        "admin-only/",
        admin_only,
        name="admin_only",
    ),

    path(
        "hr-only/",
        hr_only,
        name="hr_only",
    ),

    path(
        "interviewer-only/",
        interviewer_only,
        name="interviewer_only",
    ),
]