# AI-Enabled Recruitment Screening and Interview Intelligence Portal

Local Django 5 prototype covering candidate ingestion, Django templates/admin, AJAX endpoints, cookies/sessions, middleware, PostgreSQL ORM/raw SQL, DRF + JWT, OTP prototype, Celery + Redis, ML, NLTK NLP and a minimal Keras ANN.

## Windows setup
1. Install Python 3.12, PostgreSQL and Redis (Memurai/Redis-compatible Windows service is fine).
2. Create DB: `recruitment_db` in pgAdmin.
3. `python -m venv env` then `env\Scripts\activate`.
4. `pip install -r requirements.txt`.
5. Set environment variables from `.env.example` (or edit defaults in settings for local practice).
6. `python manage.py makemigrations recruitment` then `python manage.py migrate`.
7. `python manage.py createsuperuser` (choose your own local admin credentials).
8. Terminal 1: `python manage.py runserver`.
9. Terminal 2: start Redis, then `celery -A recruitment_portal worker -l info -P solo` on Windows.
10. Open `/admin/`, create JobRole records, then use `/upload/`. Swagger is `/api/docs/`.

## JWT/API testing
POST `/api/register/`, then `/api/verify-otp/`; activate/staff the HR user in admin for HR permission. POST `/api/login/` to receive access/refresh tokens. Use `Authorization: Bearer <access>` for secured endpoints. Refresh at `/api/token/refresh/`. Candidate CRUD: `/api/candidates/`; batch status: `/api/batches/`; screening: `/api/screening/`; feedback: `/api/feedback/`; ML prediction: `/api/ml/predict/`.

## ML/NLP/DL
Run `python ml_engine/train_ml.py` to compare Logistic Regression and Random Forest and save a model. Run `python ml_engine/train_ann.py` for the Keras prototype. For NLTK, first run Python and download `punkt`, `averaged_perceptron_tagger` (newer NLTK versions may request language-specific resource names). `ml_engine/nlp.py` contains tokenization, TF-IDF vectorization, POS tagging and skill matching.

## Sample files
`data/sample_candidates.csv` is provided. Uploads generate `data/accepted_rows.csv` and `data/rejected_rows.csv` through the ingestion utility. Add a sample resume under `media/resumes/` as needed.

## Important
This is a complete assessment starter/prototype, not a production deployment. Email is intentionally a local OTP prototype unless SMTP is configured. Never hard-code real secrets. See `notes.txt` for limitations and `sql_queries.sql` for the requested PostgreSQL examples.
