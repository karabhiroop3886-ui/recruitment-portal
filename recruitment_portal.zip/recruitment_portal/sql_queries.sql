-- Search / WHERE / AND / OR / LIKE / BETWEEN / ORDER BY / LIMIT
SELECT * FROM recruitment_candidate WHERE college ILIKE '%college%' AND (skills ILIKE '%python%' OR skills ILIKE '%django%') ORDER BY expected_salary LIMIT 20;
SELECT * FROM recruitment_candidate WHERE expected_salary BETWEEN 300000 AND 700000;
-- Aggregation, GROUP BY, HAVING
SELECT role_id, COUNT(*) candidate_count, SUM(expected_salary) salary_sum, MIN(expected_salary), MAX(expected_salary), AVG(expected_salary) FROM recruitment_candidate GROUP BY role_id HAVING COUNT(*) >= 1;
-- Inner join
SELECT c.name,r.name role FROM recruitment_candidate c INNER JOIN recruitment_jobrole r ON c.role_id=r.id;
-- Full outer join
SELECT r.name,c.name FROM recruitment_jobrole r FULL OUTER JOIN recruitment_candidate c ON c.role_id=r.id;
-- Natural join example (demonstration; only suitable when identically named columns are intended)
SELECT * FROM recruitment_candidate NATURAL JOIN recruitment_screeningresult;
-- UNION ALL selected and waitlisted
SELECT candidate_id,status FROM recruitment_screeningresult WHERE status='SELECTED' UNION ALL SELECT candidate_id,status FROM recruitment_screeningresult WHERE status='WAITLISTED';
-- INTERSECT Python and Django
SELECT id FROM recruitment_candidate WHERE skills ILIKE '%python%' INTERSECT SELECT id FROM recruitment_candidate WHERE skills ILIKE '%django%';
