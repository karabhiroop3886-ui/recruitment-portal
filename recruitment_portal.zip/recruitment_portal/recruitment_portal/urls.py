from django.contrib import admin
from django.urls import path, include

from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularSwaggerView,
)


urlpatterns = [

    # --------------------------------
    # DJANGO ADMIN
    # --------------------------------
    path(
        "admin/",
        admin.site.urls
    ),


    # --------------------------------
    # RECRUITMENT WEB PORTAL
    # --------------------------------
    path(
        "",
        include("recruitment.urls")
    ),


    # --------------------------------
    # REST API
    # --------------------------------
    path(
        "api/",
        include("api.urls")
    ),


    # --------------------------------
    # JWT LOGIN
    # --------------------------------
    # Send username + password here.
    # Returns access + refresh tokens.
    path(
        "api/token/",
        TokenObtainPairView.as_view(),
        name="token_obtain_pair"
    ),


    # --------------------------------
    # JWT REFRESH
    # --------------------------------
    # Send refresh token here to get
    # a new access token.
    path(
        "api/token/refresh/",
        TokenRefreshView.as_view(),
        name="token_refresh"
    ),


    # --------------------------------
    # OPENAPI SCHEMA
    # --------------------------------
    path(
        "api/schema/",
        SpectacularAPIView.as_view(),
        name="schema"
    ),


    # --------------------------------
    # SWAGGER DOCUMENTATION
    # --------------------------------
    path(
        "api/docs/",
        SpectacularSwaggerView.as_view(
            url_name="schema"
        ),
        name="swagger-ui"
    ),
]