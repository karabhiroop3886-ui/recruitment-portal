from django import forms
from .models import Candidate, ApplicationBatch
from django.contrib.auth.models import User


class CandidateForm(forms.ModelForm):
    class Meta:
        model = Candidate

        fields = [
            "candidate_name",
            "email",
            "phone",
            "college",
            "applied_role",
            "skills",
            "experience_months",
            "notice_period_days",
            "expected_salary",
            "resume_text",
            "portfolio_url",
            "historical_selection_status",
            "batch",
        ]

        widgets = {
            "email": forms.EmailInput(
                attrs={
                    "id": "candidate-email"
                }
            )
        }


class CandidateUploadForm(forms.Form):
    batch_name = forms.CharField(
        max_length=100,
        label="Batch Name"
    )

    candidate_file = forms.FileField(
        label="Candidate CSV/Excel File"
    )


class RegistrationForm(forms.ModelForm):

    password = forms.CharField(
        widget=forms.PasswordInput
    )

    confirm_password = forms.CharField(
        widget=forms.PasswordInput
    )

    ROLE_CHOICES = [
        ("HR", "HR"),
        ("Interviewer", "Interviewer"),
    ]

    role = forms.ChoiceField(
        choices=ROLE_CHOICES
    )

    class Meta:
        model = User

        fields = [
            "username",
            "email",
            "password",
        ]

    def clean(self):

        cleaned_data = super().clean()

        password = cleaned_data.get(
            "password"
        )

        confirm_password = cleaned_data.get(
            "confirm_password"
        )

        if password != confirm_password:

            raise forms.ValidationError(
                "Passwords do not match."
            )

        return cleaned_data


class BatchSelectionForm(forms.Form):

    batch = forms.ModelChoiceField(
        queryset=ApplicationBatch.objects.all(),
        empty_label="Select Batch"
    )