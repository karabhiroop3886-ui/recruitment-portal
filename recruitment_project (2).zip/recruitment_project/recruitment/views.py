import pandas as pd
from .ingestion import process_candidate_file
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import (
    Candidate,
    InterviewSlot,
    JobRole,
    ApplicationBatch,
)

from django.shortcuts import render, redirect, get_object_or_404

from .models import Candidate
from .forms import (
    CandidateForm,
    CandidateUploadForm,
    RegistrationForm,
    BatchSelectionForm,
)
from django.contrib.auth.models import Group

from django.contrib.auth.decorators import (
    login_required,
    user_passes_test,
)


def is_hr(user):

    return (
        user.is_superuser
        or
        user.groups.filter(
            name="HR"
        ).exists()
    )


def is_interviewer(user):

    return (
        user.is_superuser
        or
        user.groups.filter(
            name="Interviewer"
        ).exists()
    )

@login_required
def candidate_list(request):

    candidates = Candidate.objects.all()

    selected_role = request.GET.get("role")

    if not selected_role:
        selected_role = request.COOKIES.get(
            "last_selected_role"
        )

    if selected_role:
        candidates = candidates.filter(
            applied_role_id=selected_role
        )

    roles = JobRole.objects.all()

    response = render(
        request,
        "recruitment/candidate_list.html",
        {
            "candidates": candidates,
            "roles": roles,
            "selected_role": selected_role,
        }
    )

    if request.GET.get("role"):
        response.set_cookie(
            "last_selected_role",
            selected_role,
            max_age=60 * 60 * 24 * 30
        )

    return response

@login_required
def candidate_create(request):

    if request.method == "POST":

        form = CandidateForm(request.POST)

        if form.is_valid():
            form.save()

            return redirect("candidate_list")

    else:
        form = CandidateForm()

    return render(
        request,
        "recruitment/candidate_form.html",
        {
            "form": form,
            "title": "Add Candidate"
        }
    )

@login_required
def candidate_detail(request, id):

    candidate = get_object_or_404(
        Candidate,
        id=id
    )

    return render(
        request,
        "recruitment/candidate_detail.html",
        {
            "candidate": candidate
        }
    )

@login_required
def candidate_edit(request, id):

    candidate = get_object_or_404(
        Candidate,
        id=id
    )

    if request.method == "POST":

        form = CandidateForm(
            request.POST,
            instance=candidate
        )

        if form.is_valid():
            form.save()

            return redirect(
                "candidate_detail",
                id=candidate.id
            )

    else:
        form = CandidateForm(
            instance=candidate
        )

    return render(
        request,
        "recruitment/candidate_form.html",
        {
            "form": form,
            "title": "Edit Candidate"
        }
    )

@login_required
def candidate_delete(request, id):

    candidate = get_object_or_404(
        Candidate,
        id=id
    )

    if request.method == "POST":
        candidate.delete()

        return redirect(
            "candidate_list"
        )

    return render(
        request,
        "recruitment/candidate_delete.html",
        {
            "candidate": candidate
        }
    )

@login_required
def upload_candidates(request):

    form = CandidateUploadForm()

    preview_data = None
    error_message = None

    if request.method == "POST":

        form = CandidateUploadForm(
            request.POST,
            request.FILES
        )

        if form.is_valid():

            uploaded_file = request.FILES["candidate_file"]

            # Check if file is empty
            if uploaded_file.size == 0:

                error_message = "Uploaded file is empty."

            else:

                filename = uploaded_file.name.lower()

                try:

                    # Read CSV
                    if filename.endswith(".csv"):

                        df = pd.read_csv(uploaded_file)

                    # Read Excel
                    elif filename.endswith(".xlsx"):

                        df = pd.read_excel(uploaded_file)

                    else:

                        error_message = (
                            "Invalid file format. "
                            "Please upload CSV or XLSX file."
                        )

                        df = None


                    if df is not None:

                        required_columns = [
                            "candidate_name",
                            "email",
                            "phone",
                            "college",
                            "applied_role",
                            "skills",
                            "experience_months",
                            "notice_period_days",
                            "expected_salary",
                            "resume_text",
                            "portfolio_url",
                            "historical_selection_status",
                        ]


                        missing_columns = [
                            column
                            for column in required_columns
                            if column not in df.columns
                        ]


                        if missing_columns:

                            error_message = (
                                "Missing columns: "
                                + ", ".join(missing_columns)
                            )

                        elif df.empty:

                            error_message = (
                                "The uploaded file contains no candidate rows."
                            )

                        else:

                            accepted_df, rejected_df = (
                                process_candidate_file(df)
                                )

                            preview_data = (
                            accepted_df
                            .head(10)
                            .to_dict(
                            orient="records"
                                )
                             )


                except Exception as e:

                    error_message = (
                        "Could not read the uploaded file."
                    )


    context = {
        "form": form,
        "preview_data": preview_data,
        "error_message": error_message,
    }

    return render(
        request,
        "recruitment/upload_candidates.html",
        context
    )

def check_email(request):

    if request.method == "POST":

        email = request.POST.get(
            "email",
            ""
        ).strip().lower()

        exists = Candidate.objects.filter(
            email__iexact=email
        ).exists()

        return JsonResponse(
            {
                "exists": exists
            }
        )

    return JsonResponse(
        {
            "error": "Invalid request"
        },
        status=400
    )

def register_user(request):

    if request.method == "POST":

        form = RegistrationForm(
            request.POST
        )

        if form.is_valid():

            user = form.save(
                commit=False
            )

            user.set_password(
                form.cleaned_data["password"]
            )

            user.save()


            role = form.cleaned_data[
                "role"
            ]


            group = Group.objects.get(
                name=role
            )


            user.groups.add(
                group
            )


            return redirect(
                "login"
            )

    else:

        form = RegistrationForm()


    return render(
        request,
        "recruitment/register.html",
        {
            "form": form
        }
    )

@login_required
@user_passes_test(is_hr)
def select_screening_batch(request):

    current_batch_id = request.session.get(
        "current_screening_batch"
    )

    if request.method == "POST":

        form = BatchSelectionForm(
            request.POST
        )

        if form.is_valid():

            batch = form.cleaned_data[
                "batch"
            ]

            request.session[
                "current_screening_batch"
            ] = batch.id

            return redirect(
                "select_screening_batch"
            )

    else:
        form = BatchSelectionForm()


    current_batch = None

    if current_batch_id:

        current_batch = (
            ApplicationBatch.objects
            .filter(
                id=current_batch_id
            )
            .first()
        )


    return render(
        request,
        "recruitment/select_batch.html",
        {
            "form": form,
            "current_batch": current_batch,
        }
    )