from django.contrib import admin

from .models import (
    JobRole,
    Candidate,
    ApplicationBatch,
    ScreeningResult,
    InterviewSlot,
    InterviewFeedback,
)


@admin.register(JobRole)
class JobRoleAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "role_name",
        "required_skills",
    )

    search_fields = (
        "role_name",
        "required_skills",
    )


@admin.register(ApplicationBatch)
class ApplicationBatchAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "batch_name",
        "status",
        "uploaded_at",
    )

    list_filter = (
        "status",
        "uploaded_at",
    )

    search_fields = (
        "batch_name",
    )


@admin.register(Candidate)
class CandidateAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "candidate_name",
        "email",
        "phone",
        "college",
        "applied_role",
        "experience_months",
    )

    list_filter = (
        "applied_role",
        "college",
        "historical_selection_status",
    )

    search_fields = (
        "candidate_name",
        "email",
        "phone",
        "college",
        "skills",
    )

    fieldsets = (
        (
            "Basic Information",
            {
                "fields": (
                    "candidate_name",
                    "email",
                    "phone",
                    "college",
                )
            },
        ),
        (
            "Job Information",
            {
                "fields": (
                    "applied_role",
                    "skills",
                    "experience_months",
                    "notice_period_days",
                    "expected_salary",
                )
            },
        ),
        (
            "Additional Information",
            {
                "fields": (
                    "resume_text",
                    "portfolio_url",
                    "historical_selection_status",
                    "batch",
                )
            },
        ),
    )


@admin.register(ScreeningResult)
class ScreeningResultAdmin(admin.ModelAdmin):
    list_display = (
        "candidate",
        "rule_score",
        "ml_score",
        "status",
        "created_at",
    )

    list_filter = (
        "status",
        "created_at",
    )

    search_fields = (
        "candidate__candidate_name",
        "candidate__email",
    )


@admin.register(InterviewSlot)
class InterviewSlotAdmin(admin.ModelAdmin):
    list_display = (
        "job_role",
        "interview_date",
        "interview_time",
        "is_available",
    )

    list_filter = (
        "job_role",
        "interview_date",
        "is_available",
    )

    search_fields = (
        "job_role__role_name",
    )


@admin.register(InterviewFeedback)
class InterviewFeedbackAdmin(admin.ModelAdmin):
    list_display = (
        "candidate",
        "interviewer_name",
        "rating",
        "interview_slot",
        "created_at",
    )

    list_filter = (
        "rating",
        "created_at",
    )

    search_fields = (
        "candidate__candidate_name",
        "interviewer_name",
    )