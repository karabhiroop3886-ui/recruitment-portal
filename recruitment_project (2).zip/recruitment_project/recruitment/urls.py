from django.urls import path
from . import views
from django.contrib.auth import views as auth_views


urlpatterns = [
    path("", views.candidate_list, name="candidate_list"),

    path(
        "candidate/add/",
        views.candidate_create,
        name="candidate_create",
    ),

    path(
        "candidate/<int:id>/",
        views.candidate_detail,
        name="candidate_detail",
    ),

    path(
        "candidate/<int:id>/edit/",
        views.candidate_edit,
        name="candidate_edit",
    ),

    path(
        "candidate/<int:id>/delete/",
        views.candidate_delete,
        name="candidate_delete",
    ),

    path(
    "candidates/upload/",
    views.upload_candidates,
    name="upload_candidates",
    ),

    path(
    "ajax/check-email/",
    views.check_email,
    name="check_email",
    ),

    path(
    "register/",
    views.register_user,
    name="register"
    ),

    path(
    "login/",
    auth_views.LoginView.as_view(
        template_name="recruitment/login.html"
    ),
    name="login"
    ),

    path(
    "logout/",
    auth_views.LogoutView.as_view(),
    name="logout"
    ),

    path(
    "screening/select-batch/",
    views.select_screening_batch,
    name="select_screening_batch"
    ),
]