import re
import pandas as pd


class InvalidCandidateData(Exception):
    pass


EMAIL_PATTERN = r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"

PHONE_PATTERN = r"^[6-9]\d{9}$"


def clean_text(value):
    if pd.isna(value):
        return ""

    value = str(value)

    value = value.strip()

    value = " ".join(value.split())

    return value


def is_valid_email(email):
    return bool(
        re.match(
            EMAIL_PATTERN,
            email
        )
    )


def is_valid_phone(phone):
    return bool(
        re.match(
            PHONE_PATTERN,
            phone
        )
    )


def process_candidate_file(df):

    accepted_rows = []

    rejected_rows = []

    seen_emails = set()

    for index, row in df.iterrows():

        errors = []

        candidate = {
            "candidate_name": clean_text(
                row.get("candidate_name")
            ),

            "email": clean_text(
                row.get("email")
            ).lower(),

            "phone": clean_text(
                row.get("phone")
            ),

            "college": clean_text(
                row.get("college")
            ),

            "applied_role": clean_text(
                row.get("applied_role")
            ),

            "skills": clean_text(
                row.get("skills")
            ),

            "experience_months": row.get(
                "experience_months"
            ),

            "notice_period_days": row.get(
                "notice_period_days"
            ),

            "expected_salary": row.get(
                "expected_salary"
            ),

            "resume_text": clean_text(
                row.get("resume_text")
            ),

            "portfolio_url": clean_text(
                row.get("portfolio_url")
            ),

            "historical_selection_status": clean_text(
                row.get(
                    "historical_selection_status"
                )
            ),
        }


        # Candidate name validation
        if not candidate["candidate_name"]:

            errors.append(
                "Candidate name is required"
            )


        # Email validation
        if not candidate["email"]:

            errors.append(
                "Email is required"
            )

        elif not is_valid_email(
            candidate["email"]
        ):

            errors.append(
                "Invalid email"
            )


        # Duplicate email validation
        if candidate["email"] in seen_emails:

            errors.append(
                "Duplicate email"
            )

        else:

            seen_emails.add(
                candidate["email"]
            )


        # Phone validation
        if not candidate["phone"]:

            errors.append(
                "Phone is required"
            )

        elif not is_valid_phone(
            candidate["phone"]
        ):

            errors.append(
                "Invalid phone number"
            )


        # College validation
        if not candidate["college"]:

            errors.append(
                "College is required"
            )


        # Applied role validation
        if not candidate["applied_role"]:

            errors.append(
                "Applied role is required"
            )


        # Skills validation
        if not candidate["skills"]:

            errors.append(
                "Skills are required"
            )


        # Experience validation
        try:

            experience = int(
                candidate["experience_months"]
            )

            if experience < 0:

                errors.append(
                    "Experience cannot be negative"
                )

            candidate[
                "experience_months"
            ] = experience

        except (ValueError, TypeError):

            errors.append(
                "Invalid experience months"
            )


        # Notice period validation
        try:

            notice_period = int(
                candidate["notice_period_days"]
            )

            if notice_period < 0:

                errors.append(
                    "Notice period cannot be negative"
                )

            candidate[
                "notice_period_days"
            ] = notice_period

        except (ValueError, TypeError):

            errors.append(
                "Invalid notice period"
            )


        # Salary validation
        try:

            salary = float(
                candidate["expected_salary"]
            )

            if salary < 0:

                errors.append(
                    "Salary cannot be negative"
                )

            candidate[
                "expected_salary"
            ] = salary

        except (ValueError, TypeError):

            errors.append(
                "Invalid expected salary"
            )


        if errors:

            rejected_candidate = candidate.copy()

            rejected_candidate["reason"] = (
                "; ".join(errors)
            )

            rejected_rows.append(
                rejected_candidate
            )

        else:

            accepted_rows.append(
                candidate
            )


    accepted_df = pd.DataFrame(
        accepted_rows
    )

    rejected_df = pd.DataFrame(
        rejected_rows
    )


    accepted_df.to_csv(
        "accepted_rows.csv",
        index=False
    )


    rejected_df.to_csv(
        "rejected_rows.csv",
        index=False
    )


    return accepted_df, rejected_df