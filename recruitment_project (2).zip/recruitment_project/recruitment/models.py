from django.db import models


class JobRole(models.Model):
    role_name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    required_skills = models.CharField(max_length=255)

    def __str__(self):
        return self.role_name


class ApplicationBatch(models.Model):
    batch_name = models.CharField(max_length=100)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=50, default="Pending")

    def __str__(self):
        return self.batch_name


class Candidate(models.Model):
    candidate_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    college = models.CharField(max_length=150)
    applied_role = models.ForeignKey(
        JobRole,
        on_delete=models.CASCADE
    )

    skills = models.TextField()
    experience_months = models.IntegerField(default=0)
    notice_period_days = models.IntegerField(default=0)

    expected_salary = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )

    resume_text = models.TextField(blank=True)
    portfolio_url = models.URLField(blank=True)

    historical_selection_status = models.CharField(
        max_length=50,
        blank=True
    )

    batch = models.ForeignKey(
        ApplicationBatch,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    def __str__(self):
        return self.candidate_name


class ScreeningResult(models.Model):
    candidate = models.OneToOneField(
        Candidate,
        on_delete=models.CASCADE
    )

    rule_score = models.FloatField(default=0)
    ml_score = models.FloatField(default=0)

    status = models.CharField(
        max_length=50,
        default="Pending"
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.candidate.candidate_name} - {self.status}"


class InterviewSlot(models.Model):
    job_role = models.ForeignKey(
        JobRole,
        on_delete=models.CASCADE
    )

    interview_date = models.DateField()
    interview_time = models.TimeField()
    is_available = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.job_role.role_name} - {self.interview_date}"


class InterviewFeedback(models.Model):
    candidate = models.ForeignKey(
        Candidate,
        on_delete=models.CASCADE
    )

    interview_slot = models.ForeignKey(
        InterviewSlot,
        on_delete=models.CASCADE
    )

    interviewer_name = models.CharField(max_length=100)
    rating = models.IntegerField()
    comments = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback - {self.candidate.candidate_name}"