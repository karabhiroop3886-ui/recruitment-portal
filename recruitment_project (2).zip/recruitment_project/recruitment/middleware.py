import time

from django.shortcuts import redirect


class RecruitmentMiddleware:

    def __init__(self, get_response):

        self.get_response = get_response


    def __call__(self, request):

        start_time = time.time()


        protected_paths = [
            "/dashboard/",
            "/screening/",
        ]


        for path in protected_paths:

            if request.path.startswith(path):

                if not request.user.is_authenticated:

                    return redirect(
                        "login"
                    )


        response = self.get_response(
            request
        )


        end_time = time.time()

        processing_time = (
            end_time - start_time
        )


        role = "Anonymous"

        if request.user.is_authenticated:

            if request.user.is_superuser:

                role = "Admin"

            else:

                group = (
                    request.user.groups
                    .first()
                )

                if group:
                    role = group.name

                else:
                    role = "User"


        print(
            f"PATH: {request.path} | "
            f"METHOD: {request.method} | "
            f"TIME: {processing_time:.4f}s | "
            f"ROLE: {role}"
        )


        return response